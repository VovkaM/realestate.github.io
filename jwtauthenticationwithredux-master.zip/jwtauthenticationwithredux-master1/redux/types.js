export const REGISTER = 'register';
export const AUTHENTICATE = 'authenticate';
export const DEAUTHENTICATE = 'deauthenticate';
export const USER = 'user';