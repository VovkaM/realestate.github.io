module.exports = {
    API: 'http://localhost:8000/api/v1',
  };