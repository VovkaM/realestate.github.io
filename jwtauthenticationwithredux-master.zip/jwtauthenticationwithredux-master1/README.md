# JWT Authentication using Redux in Next.js

![Cover](static/jwt_next_redux.jpg?raw=true "Cover")
